<div class="pure-u-1 pure-u-md-1-<?php echo $perrow; ?>">
<div class="obox_basic" style="text-align:center">
 <div class="upg_text_over_image upg_fixed_height">
<?php
echo '<a href="'.$permalink.'" border=0><img src="'.$image.'"></a>';

?>
</div>
<div class="upg_headline" style="text-align:center"><?php echo $thetitle; ?></div>
<?php echo $the_content; ?>
</div>
</div>