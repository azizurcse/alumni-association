
     <h3><?php echo $thetitle; ?></h3>
	 <div class="body" style="text-align:center" >
	 <div class="upg_text_over_image">
	<?php
	
	echo '<a href="'.$permalink.'" border=0><img src="'.$image_large.'"></a>';
	
	?>
	 <?php echo $notice; ?>
	</div>
	</div>
	
