<?php
function upg_sub_image_gallery() 
{
$options = get_option('upg_settings');
 if(upg_sub_image_gallery_allowed_post_type())
 {


	
	$gallery="";
	global $post;
	ob_start();
	
			
		if(isset($options['sub_show_add_button']) && $options['sub_show_add_button']=='1' )
		{
		?>
		<script language="javascript" type="text/javascript">
function showHide(shID) {
   if (document.getElementById(shID)) {
      if (document.getElementById(shID+'-show').style.display != 'none') {
         document.getElementById(shID+'-show').style.display = 'none';
         document.getElementById(shID).style.display = 'block';
      }
      else {
         document.getElementById(shID+'-show').style.display = 'inline';
         document.getElementById(shID).style.display = 'none';
      }
   }
}
</script>
<style type="text/css">
   /* This CSS is just for presentational purposes. */
  
   #upg_sub_image_form {
      width: 100%;
      margin: 0 auto;
      }
  

   /* This CSS is used for the Show/Hide functionality. */
   .more {
	   	  <?php
	  $title='';
	if (isset($_POST['user-submitted-title'], $_POST['upg-nonce']) && !empty($_POST['user-submitted-title']) && wp_verify_nonce($_POST['upg-nonce'], 'upg-nonce')) 
	$title=sanitize_text_field($_POST['user-submitted-title']);
	if($title=='')
	echo 'display: none;';
?>
     
      border-top: 1px dotted #666;
      border-bottom: 1px dotted #666; }
   a.showLink, a.hideLink {
	   <?php
	   if($title!='')
	echo 'display: none;';
	   ?>
      text-decoration: none;
      color: #36f;
      padding-left: 8px;
       }
   a.hideLink {
      }
   a.showLink:hover, a.hideLink:hover {
      border-bottom: 1px dotted #36f; }
</style>

   <div id="upg_sub_image_form">
     
      <p><a href="#" id="example-show" class="showLink pure-button" onclick="showHide('example');return false;"><i class="fa fa-upload fa-lg"></i> Post Image</a></p>
      <div id="example" class="more">
       <?php 
	   echo do_shortcode( '[upg-post type="subimage"]' );
	   ?>
         <p><a href="#" id="example-hide" class="hideLink pure-button" onclick="showHide('example');return false;"> <i class="fa fa-times fa-lg"></i> Cancel</a></p>
      </div>
   </div>
		
		<?php
	}
	
	
	$attachment_ids = upg_sub_image_gallery_get_image_ids();
	if ( $attachment_ids ) 
	{ 
		
		$has_gallery_images = get_post_meta( get_the_ID(), '_upg_sub_image_gallery', true );

		if ( !$has_gallery_images )
			return;

		// convert string into array
		$has_gallery_images = explode( ',', get_post_meta( get_the_ID(), '_upg_sub_image_gallery', true ) );

		
		// clean the array (remove empty values)
		$has_gallery_images = array_filter( $has_gallery_images );

	
		
		//echo "Total Images :".upg_sub_image_gallery_count_images();
		
		
		
		?>

	
<div class="pure-g">
    <div class="pure-u-1">
		<?php
		foreach ( $attachment_ids as $attachment_id ) {
			
			//Check if file exists
			$image = wp_get_attachment_image_src($attachment_id);
			if($image)
			{	
			
			// get original image
			$image_link	= wp_get_attachment_image_src( $attachment_id, 'thumbnail',true );
			$image_link	= $image_link[0];
			$image_large_link	= wp_get_attachment_image_src( $attachment_id, 'large');
			$image_large_link	= $image_large_link[0];
			
			//echo $image_link;
			
			
			$image_title = get_post( $attachment_id )->post_title ? esc_attr( get_post( $attachment_id )->post_title ) : '';
			
			$image_approve = get_post( $attachment_id )->_isapprove ? esc_attr( get_post( $attachment_id )->_isapprove ) : '';
			
			$title=$image_title;
			$preview_type="wp-upg";
			
			
			if($options['approve_show']=='1')
			{
			
				if($image_approve==1)
				{
				echo '<div class="odude_img">';
				echo "<a href='".$image_large_link."' title='".$title."' class='".$preview_type."'><img src='".$image_link."' > </a>";
				echo '</div>';
				}
			}
			else
			{
				echo '<div class="odude_img">';
				echo "<a href='".$image_large_link."' title='".$title."' class='".$preview_type."'><img src='".$image_link."' > </a>";
				echo '</div>';
			}
			
			}
			
			
			
		}
		?>
		</div>
		</div>
		
<?php
				
	}
	
	
	$gallery = ob_get_clean();
		
		return apply_filters( 'upg_sub_image_gallery', $gallery );
}	
	
}
/**
 * Is the currently viewed post type allowed?
 * For use on the front-end when loading scripts etc

 */
function upg_sub_image_gallery_allowed_post_type() {

	// get currently viewed post type
	$post_type = ( string ) get_post_type();

	//echo $post_type; exit; // download

	// get the allowed post type from the DB
	$settings = ( array ) get_option( 'upg_settings' );
	$post_types = isset( $settings['post_types'] ) ? $settings['post_types'] : '';

	// post types don't exist, bail
	if ( ! $post_types )
		return;

	// check the two against each other
	if ( array_key_exists( $post_type, $post_types ) )
		return true;
}

function upg_sub_image_gallery_allowed_post_types() {
	
	$options = get_option('upg_settings');
	
	$post_types = isset( $options['post_types'] ) ? $options['post_types'] : '';

	// post types don't exist, bail
	if ( ! $post_types )
		return;

	return $post_types;

}

function upg_sub_image_gallery_get_post_types() {

	$args = array(
		'public' => true
	);

	$post_types = array_map( 'ucfirst', get_post_types( $args ) );

	// remove attachment
	unset( $post_types[ 'attachment' ] );

	return apply_filters( 'upg_sub_image_gallery_get_post_types', $post_types );

}

function upg_sub_image_gallery_get_image_ids() {
	global $post;

	if( ! isset( $post->ID) )
		return;

	$attachment_ids = get_post_meta( $post->ID, '_upg_sub_image_gallery', true );
	$attachment_ids = explode( ',', $attachment_ids );

	return array_filter( $attachment_ids );
}

function upg_sub_image_gallery_count_images() {

	$images = get_post_meta( get_the_ID(), '_upg_sub_image_gallery', true );
	$images = explode( ',', $images );

	$number = count( $images );

	return $number;
}

/**
 * Append gallery images to page automatically
 */
 /*
function upg_sub_image_gallery_append_to_content( $content ) {

	if ( is_singular() && is_main_query() && upg_sub_image_gallery_allowed_post_types() ) {
		$new_content = upg_sub_image_gallery();
		$content .= $new_content;
		
	}
	

	return $content;

}
add_filter( 'the_content', 'upg_sub_image_gallery_append_to_content' );
*/
/**

 */
function upg_sub_image_gallery_save_post( $post_id ) {

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        return;

    $post_types = upg_sub_image_gallery_allowed_post_types();

    // check user permissions
    if ( isset( $_POST[ 'post_type' ] ) && !array_key_exists( $_POST[ 'post_type' ], $post_types ) ) {
        if ( !current_user_can( 'edit_page', $post_id ) )
            return;
    }
    else {
        if ( !current_user_can( 'edit_post', $post_id ) )
            return;
    }

 
    if ( isset( $_POST[ 'image_gallery' ] ) && !empty( $_POST[ 'image_gallery' ] ) ) {

        $attachment_ids = sanitize_text_field( $_POST['image_gallery'] );

        // turn comma separated values into array
        $attachment_ids = explode( ',', $attachment_ids );

        // clean the array
        $attachment_ids = array_filter( $attachment_ids  );

        // return back to comma separated list with no trailing comma. This is common when deleting the images
        $attachment_ids =  implode( ',', $attachment_ids );

        update_post_meta( $post_id, '_upg_sub_image_gallery', $attachment_ids );
		
				
    } else {
        delete_post_meta( $post_id, '_upg_sub_image_gallery' );
    }

    

    do_action( 'upg_sub_image_gallery_save_post', $post_id );
}

//Add approve field at EDIT MEDIA LIBRARY

function upg_fields_to_edit_isapproveimage( $form_fields, $post ) {
    $isapprove = (bool) get_post_meta($post->ID, '_isapprove', true);
    $checked = ($isapprove) ? 'checked' : '';

    $form_fields['isapprove'] = array(
        'label' => 'UPG Approved ?',
        'input' => 'html',
        'html' => "<input type='checkbox' {$checked} name='attachments[{$post->ID}][isapprove]' id='attachments[{$post->ID}][isapprove]' />",
        'value' => $isapprove,
        'helps' => 'Only Approved sub-images will be visible to visitors.'
    );
    return $form_fields;

}
add_filter( 'attachment_fields_to_edit', 'upg_fields_to_edit_isapproveimage', null, 2 );

function upg_fields_to_save_isapproveimage($post, $attachment) {
    $isapprove = ($attachment['isapprove'] == 'on') ? '1' : '0';
    update_post_meta($post['ID'], '_isapprove', $isapprove);  
    return $post;  
}
add_filter( 'attachment_fields_to_save', 'upg_fields_to_save_isapproveimage', null, 2 );


function upg_sanitize_content($content) 
{
	$allowed_tags = wp_kses_allowed_html('post');
	return wp_kses(stripslashes($content), $allowed_tags);
}

function upg_prepare_post($title, $content) 
{
	$options = get_option('upg_settings');
	
	$postData = array();
	$postData['post_title']   = $title;
	$postData['post_content'] = $content;
	$postData['post_author']  = upg_get_author();
	$postData['post_type']  = 'upg';
	
	if(isset($options['publish']) && $options['publish']=='1' )
	$postData['post_status'] = 'publish';
	
	return apply_filters('upg_post_data', $postData);
}

function upg_get_author() 
{
	if ( is_user_logged_in() )
	{
		$author_id =get_current_user_id();
	} 
	else 
	{
		$options = get_option('upg_settings');
			if(!isset($options['guest_user']))
			$options['guest_user']="";
		$author_id =$options['guest_user'];
	}	
	
	
	return $author_id;
}

function upg_include_deps() 
{
	if (!function_exists('media_handle_upload')) {
		require_once (ABSPATH .'/wp-admin/includes/media.php');
		require_once (ABSPATH .'/wp-admin/includes/file.php');
		require_once (ABSPATH .'/wp-admin/includes/image.php');
	}
}
	
function upg_check_images($files) 
{
	global $upg_options;
	
	$temp = false; $errr = false; $error = array();
	
	if (isset($files['tmp_name'])) $temp = array_filter($files['tmp_name']);
	if (isset($files['error']))    $errr = array_filter($files['error']);
	
	$file_count = 0;
	if (!empty($temp)) 
	{
		foreach ($temp as $key => $value) if (is_uploaded_file($value)) $file_count++;
	}
	if (true) 
	{
		
		//if ($file_count > 1) $error[] = 'file-max';
		
		$i=0;
			
			$image = @getimagesize($temp[$i]);
			
			if (false === $image) 
			{
				$error[] = 'file-type';
				//break;
			} 
			else 
			{
				if (function_exists('exif_imagetype')) 
				if (isset($temp[$i]) && !exif_imagetype($temp[$i])) 
				{
					$error[] = 'exif_imagetype';
					//break;
				}
				/* $file = check_upload_size( $temp[$i] );
				if ( $file['error'] != '0' )
				{
					$error[] = 'max-filesize';
				} */
				
				
			}
		
	}
	else 
	{
		$files = false;
	}
	$file_data = array('error' => $error, 'file_count' => $file_count);
	return $file_data;
}		

function upg_submit_url($title, $url, $content, $category)
{
	$url=str_replace("m.youtube","www.youtube",$url);
	
	$newPost = array('id' => false, 'error' => false);
	$newPost['error'][] ="";
	
	if (empty($title))    $newPost['error'][] = 'required-title';
	if (empty($category)) $newPost['error'][] = 'required-category';
	if (empty($content))  $newPost['error'][] = 'required-description';
	if (empty($url))  $newPost['error'][] = 'required-url';
	if ($category=='-1') $newPost['error'][] = 'required-category';
	if(upg_getid_youtube($url)=='') $newPost['error'][] = 'wrong-youtube-url';
		
		
		
		$newPost['error'][]=apply_filters('upg_verify_submit', "");
		//var_dump($newPost);

		
		foreach ($newPost['error'] as $e) 
	{
		if (!empty($e)) 
		{
			unset($newPost['id']);
			return $newPost;
		}
	}
	
	$postData = upg_prepare_post($title, $content);
	
	do_action('upg_insert_before', $postData);
	$newPost['id'] = wp_insert_post($postData);
	do_action('upg_insert_after', $newPost);
	
	if ($newPost['id']) 
	{
		$post_id = $newPost['id'];
		//wp_set_post_categories($post_id, array($category));
		wp_set_object_terms($post_id, array($category),'upg_cate');
		
		add_post_meta($post_id, 'youtube_url', $url);
		
	}
	
	return apply_filters('upg_new_post', $newPost);
	
	
}
	
function upg_submit($title, $files, $content, $category)
{
	$newPost = array('id' => false, 'error' => false);
	$newPost['error'][] ="";
	
	if (empty($title))    $newPost['error'][] = 'required-title';
	if (empty($category)) $newPost['error'][] = 'required-category';
	if (empty($content))  $newPost['error'][] = 'required-description';
	
		$newPost['error'][]=apply_filters('upg_verify_submit', "");
	
	
	$file_data = upg_check_images($files, $newPost);
	$file_count       = $file_data['file_count'];
	$newPost['error'] = array_unique(array_merge($file_data['error'], $newPost['error']));
	
	if ($category=='-1') $newPost['error'][] = 'required-category';
	
	foreach ($newPost['error'] as $e) 
	{
		if (!empty($e)) 
		{
			unset($newPost['id']);
			return $newPost;
		}
	}
	
	$postData = upg_prepare_post($title, $content);
	
	do_action('upg_insert_before', $postData);
	$newPost['id'] = wp_insert_post($postData);
	do_action('upg_insert_after', $newPost);
	if ($newPost['id']) 
	{
		$post_id = $newPost['id'];
		//wp_set_post_categories($post_id, array($category));
		wp_set_object_terms($post_id, array($category),'upg_cate');
		
		//POST IMG
		do_action('upg_files_before', $files);
		
		$attach_ids = array();
		if ($files) 
		{
			upg_include_deps();
			$i=0;
				
				$key = apply_filters('upg_file_key', 'user-submitted-image-{$i}');
				
				$_FILES[$key] = array();
				$_FILES[$key]['name']     = $files['name'][$i];
				$_FILES[$key]['tmp_name'] = $files['tmp_name'][$i];
				$_FILES[$key]['type']     = $files['type'][$i];
				$_FILES[$key]['error']    = $files['error'][$i];
				$_FILES[$key]['size']     = $files['size'][$i];
				
				$attach_id = media_handle_upload($key, $post_id);
				
				if (!is_wp_error($attach_id) && wp_attachment_is_image($attach_id)) 
				{
					$attach_ids[] = $attach_id;
					add_post_meta($post_id, 'pic_name', $attach_id);
					//add_post_meta($post_id, 'meta-box-media[pic_name]', wp_get_attachment_url($attach_id));
					//echo $post_id."-image attached".$attach_id."-".wp_get_attachment_url($attach_id);
				} 
				else 
				{
					wp_delete_attachment($attach_id);
					wp_delete_post($post_id, true);
					$newPost['error'][] = 'upload-error';
					unset($newPost['id']);
					return $newPost;
				}
			
		}
		else
		{
			$newPost['error'][] = 'no-files';
		}
		do_action('upg_files_after', $attach_ids);
		//update_post_meta($post_id, $upg_post_meta_IsSubmission, true);
		
		//END
	}
	else 
	{
		$newPost['error'][] = 'post-fail';
	}
	return apply_filters('upg_new_post', $newPost);
	
}

function upg_submit_subimage($title, $files, $content, $category)
{
	$options = get_option('upg_settings');
	$newPost = array('id' => false, 'error' => false);
	$newPost['error'][] ="";
	
	if (empty($title))    $newPost['error'][] = 'required-title';
	if (empty($category)) $newPost['error'][] = 'required-post-type';
	if (empty($content))  $newPost['error'][] = 'required-description';
	
		$newPost['error'][]=apply_filters('upg_verify_submit', "");
	
	
	$file_data = upg_check_images($files, $newPost);
	$file_count       = $file_data['file_count'];
	$newPost['error'] = array_unique(array_merge($file_data['error'], $newPost['error']));
	
	if ($category=='-1') $newPost['error'][] = 'required-post-type';
	
	foreach ($newPost['error'] as $e) 
	{
		if (!empty($e)) 
		{
			unset($newPost['id']);
			return $newPost;
		}
	}
	
	
	$newPost['id'] = $category;
	
	if ($newPost['id']) 
	{
		$post_id = $newPost['id'];
				
		
		$attach_ids = array();
		if ($files) 
		{
			upg_include_deps();
			$i=0;
				
				$key = apply_filters('upg_file_key', 'user-submitted-image-{$i}');
				
				$_FILES[$key] = array();
				$_FILES[$key]['name']     = $files['name'][$i];
				$_FILES[$key]['tmp_name'] = $files['tmp_name'][$i];
				$_FILES[$key]['type']     = $files['type'][$i];
				$_FILES[$key]['error']    = $files['error'][$i];
				$_FILES[$key]['size']     = $files['size'][$i];
				
				$attach_id = media_handle_upload($key, $post_id);
				
				if (!is_wp_error($attach_id) && wp_attachment_is_image($attach_id)) 
				{
					//Get old meta value
					$key_old_value = get_post_meta( get_the_ID(), '_upg_sub_image_gallery', true );
					
					
					$attach_ids[] = $attach_id;
					
					update_post_meta($post_id, '_upg_sub_image_gallery', $key_old_value.','.$attach_id);
					
					$attachment_data = array(
						'ID' => $attach_id,
						'post_excerpt' => $title,
						'post_title' => $title,
						'post_content' => $content
						
					  );
					   
					  wp_update_post($attachment_data);
					 
						//Apporve Image at post		
						if(isset($options['publish_sub']) && $options['publish_sub']=='1' )
						{
							update_post_meta($attach_id, '_isapprove', 1);  
						}
						else
						{
							update_post_meta($attach_id, '_isapprove', 0);  
						}
					 
					
				} 
				else 
				{
					wp_delete_attachment($attach_id);
					wp_delete_post($post_id, true);
					$newPost['error'][] = 'upload-error';
					unset($newPost['id']);
					return $newPost;
				}
			
		}
		else
		{
			$newPost['error'][] = 'no-files';
		}
		do_action('upg_files_after', $attach_ids);
		//update_post_meta($post_id, $upg_post_meta_IsSubmission, true);
		
		//END
	}
	else 
	{
		$newPost['error'][] = 'post-fail';
	}
	return $newPost;
	
}


function upg_author($author)
{
	$options = get_option('upg_settings');
	if(isset($options['main_page']))
	{
		if ( get_option('permalink_structure') )
		$linku=esc_url( get_permalink($options['main_page'])."".$author->user_nicename );
		else
		$linku=esc_url( get_permalink($options['main_page'])."&user=".$author->user_nicename );
	}
	else
	{
		$linku="";
	}
	
	return  '<div class=""><a href="'.$linku.'" title='.$author->display_name.'>'.get_avatar( get_the_author_meta($author->email), $size = '50').'</a></div><div class="upg-profile-name">'.$author->display_name.'</div>';

	//return '<span class="">Submitted by: <a href="'.$linku.'">'.$author->display_name.'</a></span><br>';
	
	//return '<a href="'.$linku.'">'.get_avatar( $author->user_email,32 ).'</a><br>'.$author->display_name;
}
?>