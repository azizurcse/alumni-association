<?php
//Adding meta boxes Main Image
	function upg_meta_boxes()
	{
		$prefix = 'upg_';

		$meta_boxes = array(
				'post_img'=>array('id'=> $prefix.'image','title'=>__('Main Image/Youtube','wp-upg'),'callback'=>'upg_meta_box_image','position'=>'advanced','priority'=>'high'),
				
				'upg-layout'=>array('title'=>__('Image Preview Layout',"odudeshop"),'callback'=>'upg_meta_box_layout','position'=>'side','priority'=>'core'),
				
				'upg-extra-fields'=>array('title'=>__('Extra Custom Fields',"odudeshop"),'callback'=>'upg_meta_box_extra_field','position'=>'side','priority'=>'core'),
			);

			
			 

			$meta_boxes = apply_filters("upg_meta_box", $meta_boxes);
			foreach($meta_boxes as $id=>$meta_box)
			{
				extract($meta_box);
				add_meta_box($id, $title, $callback,'upg', $position, $priority);
			}    
			
			//Adding sub_image metabox to all selected post_type			
			 $post_types = upg_sub_image_gallery_allowed_post_types();
			 
			 if ( ! $post_types )
			return;

			foreach ( $post_types as $post_type => $status )
			{
				add_meta_box('upg_sub_images', 'UPG Sub Images Gallery', 'upg_meta_box_sub_image', $post_type, 'normal', 'low');
			}
			
			
	}
	
	function upg_meta_box_extra_field($post)
	{
		$all_upg_extra= get_post_custom($post->ID);
		$options = get_option('upg_settings');
			
		
		//Display 5 custom fields loop
		for ($x = 1; $x <= 5; $x++) 
		{
			if(isset($all_upg_extra["upg_custom_field_".$x][0]))
			$upg_custom_field[$x]=$all_upg_extra["upg_custom_field_".$x][0];
			else	
			$upg_custom_field[$x]="";
			if($options['upg_custom_field_'.$x.'_show']=='on')
			{
				if($options['upg_custom_field_type_'.$x]=='checkbox')
				{
					?>
					<?php echo $options['upg_custom_field_'.$x]; ?>:  
					<input type="checkbox" name="upg_custom_field_<?php echo $x; ?>" value="<?php echo 'upg_custom_field_'.$x.'_checked'; ?>" 
					
					<?php if(!empty($upg_custom_field[$x]) && $upg_custom_field[$x]==$upg_custom_field[$x]) 
						echo 'checked';	?> ><hr>
					<?php
				}
				else
				{
			?>
			
			<?php echo $options['upg_custom_field_'.$x]; ?><br> <input type="text" name="upg_custom_field_<?php echo $x; ?>" value="<?php echo $upg_custom_field[$x]; ?>"><br><br>
			
			<?php
				}
			}
		}
		
	}
	
	//Image upload in post type
	 function upg_meta_box_image($post)
	{     ?>
			<script>
		jQuery(document).ready(function($){
			   $("#tabs").tabs();
		});
		  </script>
	
	<div id="tabs">
	<ul>
		
        <li><a href="#tab-1"><?php echo __("Upload Image","odudeshop");?></a></li>
       
		<li><a href="#tab-2"><?php echo __("Post Youtube URL","odudeshop");?></a></li> 
		
				
	</ul>
	 <div id="tab-1">
		<?php include(dirname(__FILE__).'/post_img.php'); ?>
	 </div>
	 <div id="tab-2">
		<?php include(dirname(__FILE__).'/youtube_url.php'); ?>
	 </div>
	 </div>
	 

        
<?php


    }

	function upg_meta_box_sub_image($post) {

    global $post;
?>

    <div id="gallery_images_container">

        <ul class="gallery_images">
            <?php

    $image_gallery = get_post_meta( $post->ID, '_upg_sub_image_gallery', true );
    $attachments = array_filter( explode( ',', $image_gallery ) );

    if ( $attachments )
        foreach ( $attachments as $attachment_id ) {
            echo '<li class="image attachment details" data-attachment_id="' . $attachment_id . '"><div class="attachment-preview"><div class="thumbnail">
                            ' . wp_get_attachment_image( $attachment_id, 'thumbnail' ) . '</div>
                            <a href="#" class="delete check" title="' . __( 'Remove image', 'wp-upg' ) . '"><div class="media-modal-icon"></div></a>
                           
                        </div></li>';
        }
?>
        </ul>


        <input type="hidden" id="image_gallery" name="image_gallery" value="<?php echo esc_attr( $image_gallery ); ?>" />
        <?php wp_nonce_field( 'wp-upg', 'wp-upg' ); ?>

    </div>
Attached images must be UPG approved before it is displayed to visitors.<br>
To approve check image details in Media Library.
    <p class="add_gallery_images hide-if-no-js">
        <a href="#"><?php _e( 'Add gallery images', 'wp-upg' ); ?></a>
    </p>

   


    <?php
    /**
     * Props to WooCommerce for the following JS code
     */
?>
    <script type="text/javascript">
        jQuery(document).ready(function($){

            // Uploading files
            var image_gallery_frame;
            var $image_gallery_ids = $('#image_gallery');
            var $gallery_images = $('#gallery_images_container ul.gallery_images');

            jQuery('.add_gallery_images').on( 'click', 'a', function( event ) {

                var $el = $(this);
                var attachment_ids = $image_gallery_ids.val();

                event.preventDefault();

                // If the media frame already exists, reopen it.
                if ( image_gallery_frame ) {
                    image_gallery_frame.open();
                    return;
                }

                // Create the media frame.
                image_gallery_frame = wp.media.frames.downloadable_file = wp.media({
                    // Set the title of the modal.
                    title: '<?php _e( 'Add Sub-Images to Gallery', 'wp-upg' ); ?>',
                    button: {
                        text: '<?php _e( 'Add to gallery', 'wp-upg' ); ?>',
                    },
                    multiple: true
                });

                // When an image is selected, run a callback.
                image_gallery_frame.on( 'select', function() {

                    var selection = image_gallery_frame.state().get('selection');

                    selection.map( function( attachment ) {

                        attachment = attachment.toJSON();

                        if ( attachment.id ) {
                            attachment_ids = attachment_ids ? attachment_ids + "," + attachment.id : attachment.id;

                             $gallery_images.append('\
                                <li class="image attachment details" data-attachment_id="' + attachment.id + '">\
                                    <div class="attachment-preview">\
                                        <div class="thumbnail">\
                                            <img src="' + attachment.url + '" />\
										 </div>\
                                       <a href="#" class="delete check" title="<?php _e( 'Remove image', 'wp-upg' ); ?>"><div class="media-modal-icon"></div></a>\
                                    </div>\
                                </li>');

                        }

                    } );

                    $image_gallery_ids.val( attachment_ids );
                });

                // Finally, open the modal.
                image_gallery_frame.open();
            });

            // Image ordering
            $gallery_images.sortable({
                items: 'li.image',
                cursor: 'move',
                scrollSensitivity:40,
                forcePlaceholderSize: true,
                forceHelperSize: false,
                helper: 'clone',
                opacity: 0.65,
                placeholder: 'eig-metabox-sortable-placeholder',
                start:function(event,ui){
                    ui.item.css('background-color','#f6f6f6');
                },
                stop:function(event,ui){
                    ui.item.removeAttr('style');
                },
                update: function(event, ui) {
                    var attachment_ids = '';

                    $('#gallery_images_container ul li.image').css('cursor','default').each(function() {
                        var attachment_id = jQuery(this).attr( 'data-attachment_id' );
                        attachment_ids = attachment_ids + attachment_id + ',';
                    });

                    $image_gallery_ids.val( attachment_ids );
                }
            });

            // Remove images
            $('#gallery_images_container').on( 'click', 'a.delete', function() {

                $(this).closest('li.image').remove();

                var attachment_ids = '';

                $('#gallery_images_container ul li.image').css('cursor','default').each(function() {
                    var attachment_id = jQuery(this).attr( 'data-attachment_id' );
                    attachment_ids = attachment_ids + attachment_id + ',';
                });

                $image_gallery_ids.val( attachment_ids );

                return false;
            } );

        });
    </script>
    <?php
}

function upg_sub_image_gallery_admin_css() { ?>

	<style>
		.attachment.details .check div {
			background-position: -60px 0;
		}

		.attachment.details .check:hover div {
			background-position: -60px 0;
		}

		.gallery_images .details.attachment {
			box-shadow: none;
		}

		.eig-metabox-sortable-placeholder {
			background: #DFDFDF;
		}

		.gallery_images .attachment.details > div {
			width: 150px;
			height: 150px;
			box-shadow: none;
		}

		.gallery_images .attachment-preview .thumbnail {
			 cursor: move;
		}

		.attachment.details div:hover .check {
			display:block;
		}

        .gallery_images:after,
        #gallery_images_container:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }

        .gallery_images > li {
            float: left;
            cursor: move;
            margin: 0 20px 20px 0;
        }

        .gallery_images li.image img {
            width: 150px;
            height: auto;
        }

    </style>

<?php 
}

?>