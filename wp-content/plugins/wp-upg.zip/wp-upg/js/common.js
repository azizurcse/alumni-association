/* Initialize jQuery Colorbox*/
jQuery(function( $ ){
 jQuery('a.wp-upg').colorbox({rel:'wp-upg'});
 jQuery(".inline").colorbox({inline:true, width:"50%", rel:'wp-upg'});
 jQuery(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390,rel:'wp-upg'});
});